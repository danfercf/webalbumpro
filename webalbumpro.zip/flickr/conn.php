<?php 
// conexion a la base
//$conexion = mysql_connect("localhost", "wapro", "wapro");
//mysql_select_db("wapro", $conexion);

$conexion = mysql_connect("internal-db.s124179.gridserver.com", "db124179_wap", "mauroymaxi");
mysql_select_db("db124179_wap", $conexion);	

?>